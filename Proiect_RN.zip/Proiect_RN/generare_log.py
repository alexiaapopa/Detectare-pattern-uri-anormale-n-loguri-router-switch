import random
import pandas as pd
import os
from datetime import datetime, timedelta

normal_messages = [
    "LINK-UP: Interface GigabitEthernet0/1 is up",
    "LINK-DOWN: Interface GigabitEthernet0/2 is down",
    "OSPF: Neighbor adjacency established",
    "DHCP: New lease granted",
    "STP: Topology change detected",
    "PORT-SECURITY: 1 MAC address learned",
    "SYSLOG: System running normally"
]

anomaly_messages = [
    "SECURITY ALERT: Possible intrusion detected",
    "AUTH-FAIL: Multiple invalid SSH attempts",
    "CPU HIGH: 98% utilization for 300 seconds",
    "DDOS DETECTED: Abnormal traffic spike",
    "PORT-SCAN: Multiple SYN packets detected",
    "CONFIG ERROR: Unexpected configuration rollback"
]

devices = ["R1", "R2", "SW1", "SW2"]

def random_timestamp():
    base = datetime.now()
    offset = timedelta(seconds=random.randint(-50000, 0))
    return (base + offset).strftime("%Y-%m-%d %H:%M:%S")

def generate_logs(n=1000, anomaly_ratio=0.15):
    base_path = r"C:\Users\A\OneDrive\Desktop\facultate\Proiect_RN\data\raw"
    os.makedirs(base_path, exist_ok=True)

    output_file = os.path.join(base_path, "generated_logs.csv")

    logs = []
    for i in range(n):
        msg = random.choice(anomaly_messages) if random.random() < anomaly_ratio else random.choice(normal_messages)
        label = 1 if msg in anomaly_messages else 0

        logs.append({
            "timestamp": random_timestamp(),
            "device": random.choice(devices),
            "severity": random.randint(0, 7),
            "message": msg,
            "label": label
        })

    df = pd.DataFrame(logs)
    
    # --- Afișăm primele 5 loguri generate ---
    print("[DEBUG] Primele 5 loguri generate:")
    print(df.head())

    df.to_csv(output_file, index=False)
    print(f"[INFO] Am generat {n} loguri → {output_file}")

if __name__ == "__main__":
    generate_logs(n=100, anomaly_ratio=0.2)
